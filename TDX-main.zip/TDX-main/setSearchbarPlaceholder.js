<script>
var placeholderText = `Your text here`;
$(document).ready (function () {
  $(`.ModuleContent [id*="SiteSearch-text"]`).attr("placeholder",placeholderText);
});
</script>
